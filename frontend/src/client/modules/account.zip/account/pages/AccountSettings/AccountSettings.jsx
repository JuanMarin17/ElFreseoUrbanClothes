// client/modules/account/pages/AccountSettings/AccountSettings.jsx
import React, { useState, useEffect } from 'react';
import { Mail, User, ShieldCheck } from 'lucide-react';
import AccountSidebar from '../../components/AccountSidebar/AccountSidebar';
import './AccountSettings.css';

// --- COMPONENTES INTERNOS DE ESTA PÁGINA ---

/* 1. Formulario de Información Básica */
const BasicInfoCard = ({ userData, onSave }) => (
  <div className="vp-form-card">
    <div className="vp-card-header">
      <h3 className="vp-title" style={{fontSize: '1.4rem'}}>Mi Perfil</h3>
      <p className="vp-card-subtitle">Actualiza tu información personal de "fresa"</p>
    </div>
    <form onSubmit={onSave}>
      <div className="vp-form-grid">
        <div style={{position: 'relative'}}>
          <User size={18} style={{position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: 'var(--freseo-text-muted)'}} />
          <input type="text" defaultValue={userData.fullName} placeholder="Nombre Completo" className="vp-input-main" style={{paddingLeft: '45px'}} />
        </div>
        <div style={{position: 'relative'}}>
          <Mail size={18} style={{position: 'absolute', left: '15px', top: '50%', transform: 'translateY(-50%)', color: 'var(--freseo-text-muted)'}} />
          <input type="email" defaultValue={userData.email} placeholder="Correo Electrónico" className="vp-input-main" style={{paddingLeft: '45px'}} />
        </div>
        <button type="submit" className="vp-submit-btn">GUARDAR CAMBIOS</button>
      </div>
    </form>
  </div>
);

/* 2. Sección de Seguridad (Cambiar Contraseña, 2FA, Sesiones) */
const SecurityCard = ({ onSave }) => (
  <div className="vp-form-card">
    <div className="vp-card-header">
      <h3 className="vp-title" style={{fontSize: '1.4rem', display: 'flex', alignItems: 'center', gap: '10px'}}>
        <ShieldCheck size={22} className="vp-nav-icon active" style={{margin: '0'}}/> Seguridad
      </h3>
      <p className="vp-card-subtitle">Administra tu contraseña y la protección de tu cuenta</p>
    </div>
    <form onSubmit={onSave}>
      <div className="vp-form-grid">
        <input type="password" placeholder="Contraseña Actual" className="vp-input-main" />
        <input type="password" placeholder="Nueva Contraseña" className="vp-input-main" />
        <input type="password" placeholder="Confirmar Nueva Contraseña" className="vp-input-main" />
        <button type="submit" className="vp-submit-btn">ACTUALIZAR CONTRASEÑA</button>
      </div>
    </form>
    
    <div className="vp-divider" style={{margin: '30px 0'}}></div>
    
    {/* Ideas de soporte: 2FA y Sesiones (Solo vista, sin lógica) */}
    <div className="vp-form-grid" style={{gap: '10px'}}>
        <p className="vp-card-subtitle">Autenticación de Dos Factores (2FA)</p>
        <button type="button" className="vp-submit-btn" style={{background: 'rgba(255,255,255,0.05)', color: 'var(--freseo-text-main)', border: '1px solid var(--freseo-border)'}}>CONFIGURAR 2FA</button>
    </div>
  </div>
);

// --- PÁGINA MAESTRA / CONTENEDOR PRINCIPAL ---

const AccountSettings = () => {
  // Estado para los datos del usuario (Simulados)
  const [userData, setUserData] = useState({
    fullName: 'Juan Gómez',
    email: 'juangomez@freseo.com',
    userName: 'JuanGomez'
  });

  // Simulación de carga de datos al montar el componente
  useEffect(() => {
    document.body.classList.add('freseo-account-active');
    // getUserProfile().then(data => setUserData(data));
    
    // Limpieza al desmontar
    return () => {
      document.body.classList.remove('freseo-account-active');
    };
  }, []);

  const handleSaveBasicInfo = (e) => {
    e.preventDefault();
    console.log('Guardando información básica...');
    // updateProfile(data);
  };

  const handleUpdatePassword = (e) => {
    e.preventDefault();
    console.log('Actualizando contraseña...');
    // changePassword(data);
  };

  return (
    <div className="vp-page-layout freseo-account-active">
      {/* ─── FONDO AMBIENTAL (ORBES ANIMADOS) ─── */}
      <div className="vp-bg-background">
        <div className="vp-bg-orb vp-bg-orb--1"></div>
        <div className="vp-bg-orb vp-bg-orb--2"></div>
        <div className="vp-bg-orb vp-bg-orb--3"></div>
      </div>

      {/* ─── SIDEBAR DE NAVEGACIÓN (Parte 1) ─── */}
      <AccountSidebar userName={userData.userName} />

      {/* ─── ÁREA DE CONTENIDO CENTRAL ─── */}
      <main className="vp-content-area">
        <h2 className="vp-title">Configuración de la Cuenta</h2>
        
        {/* Renderizado de los formularios de la Parte 2 */}
        <BasicInfoCard userData={userData} onSave={handleSaveBasicInfo} />
        <SecurityCard onSave={handleUpdatePassword} />
      </main>
    </div>
  );
};

export default AccountSettings;