// client/modules/account/components/AccountSidebar/AccountSidebar.jsx
import React from 'react';
import { NavLink } from 'react-router-dom';
import { User, Shield, Package, MapPin, Settings, LifeBuoy, LogOut } from 'lucide-react';
import './AccountSidebar.css';

const AccountSidebar = ({ userName }) => {
  return (
    <aside className="vp-sidebar">
      {/* Header de bienvenida con estilo del Header principal */}
      <div className="vp-profile-header">
        <div className="vp-brand-name" style={{textTransform: 'lowercase'}}>vexio</div>
        <p className="vp-welcome-msg">Hola, <span style={{fontWeight: '600'}}>{userName}</span></p>
      </div>

      {/* Lista de Navegación Principal */}
      <ul className="vp-nav-list">
        <li>
          <NavLink to="/cuenta/configuracion" end className={({ isActive }) => `vp-nav-link ${isActive ? 'active' : ''}`}>
            <span className="vp-nav-icon"><User size={18} /></span>
            <span>Mi Perfil</span>
          </NavLink>
        </li>
        <li>
          <NavLink to="/cuenta/configuracion/seguridad" className={({ isActive }) => `vp-nav-link ${isActive ? 'active' : ''}`}>
            <span className="vp-nav-icon"><Shield size={18} /></span>
            <span>Seguridad</span>
          </NavLink>
        </li>
        <li>
          <NavLink to="/cuenta/pedidos" className={({ isActive }) => `vp-nav-link ${isActive ? 'active' : ''}`}>
            <span className="vp-nav-icon"><Package size={18} /></span>
            <span>Mis Pedidos</span>
          </NavLink>
        </li>
        <li>
          <NavLink to="/cuenta/direcciones" className={({ isActive }) => `vp-nav-link ${isActive ? 'active' : ''}`}>
            <span className="vp-nav-icon"><MapPin size={18} /></span>
            <span>Libreta de Direcciones</span>
          </NavLink>
        </li>
        <li>
         <NavLink to="/cuenta/preferencias" className={({ isActive }) => `vp-nav-link ${isActive ? 'active' : ''}`}>
             <span className="vp-nav-icon"><Settings size={18} /></span> {/* Antes era Gear */}
              <span>Preferencias</span>
        </NavLink>
    </li>
      </ul>

      {/* Separador */}
      <div className="vp-divider"></div>

      {/* Lista de Soporte y Logout */}
      <ul className="vp-nav-list">
        <li>
          <NavLink to="/ayuda" className="vp-nav-link">
            <span className="vp-nav-icon"><LifeBuoy size={18} /></span>
            <span>Ayuda y Soporte</span>
          </NavLink>
        </li>
        <li>
          <button className="vp-nav-link logout" onClick={() => console.log('Logut clicked')}>
            <span className="vp-nav-icon"><LogOut size={18} /></span>
            <span>CERRAR SESIÓN</span>
          </button>
        </li>
      </ul>
    </aside>
  );
};

export default AccountSidebar;