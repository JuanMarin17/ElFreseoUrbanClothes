// client/modules/account/components/SecuritySection/SecuritySection.jsx
import React, { useState } from 'react';
import { ShieldCheck, Eye, EyeOff } from 'lucide-react';
import './SecuritySection.css';

// --- COMPONENTE INTERNO DE INPUT DE CONTRASEÑA (REUTILIZABLE) ---
const PasswordInput = ({ placeholder }) => {
  const [show, setShow] = useState(false);
  return (
    <div style={{position: 'relative'}}>
      <input 
        type={show ? 'text' : 'password'} 
        placeholder={placeholder} 
        className="vp-input-main" 
        style={{paddingRight: '45px'}} 
      />
      <button type="button" className="vp-eye-btn" onClick={() => setShow(!show)}>
        {show ? <EyeOff size={18} /> : <Eye size={18} />}
      </button>
    </div>
  );
};

// --- SECCIÓN DE SEGURIDAD PRINCIPAL ---
const SecuritySection = ({ onSavePassword }) => {
  return (
    <div className="vp-form-card">
      <div className="vp-card-header">
        <h3 className="vp-title" style={{fontSize: '1.4rem', display: 'flex', alignItems: 'center', gap: '10px'}}>
          <ShieldCheck size={22} className="vp-nav-icon active" style={{margin: '0'}}/> Seguridad
        </h3>
        <p className="vp-card-subtitle">Administra tu contraseña y la protección de tu cuenta</p>
      </div>
      
      <form onSubmit={onSavePassword}>
        <div className="vp-form-grid">
          <PasswordInput placeholder="Contraseña Actual" />
          <PasswordInput placeholder="Nueva Contraseña" />
          <PasswordInput placeholder="Confirmar Nueva Contraseña" />
          <button type="submit" className="vp-submit-btn">ACTUALIZAR CONTRASEÑA</button>
        </div>
      </form>
      
      <div className="vp-divider" style={{margin: '30px 0'}}></div>
      
      {/* Ideas de soporte: 2FA y Sesiones (Solo vista, sin lógica) */}
      <div className="vp-form-grid" style={{gap: '10px'}}>
          <p className="vp-card-subtitle">Autenticación de Dos Factores (2FA)</p>
          <button type="button" className="vp-submit-btn" style={{background: 'rgba(255,255,255,0.05)', color: 'var(--freseo-text-main)', border: '1px solid var(--freseo-border)'}}>CONFIGURAR 2FA</button>
      </div>
    </div>
  );
};

export default SecuritySection;