import React, { useState } from 'react';
import './BasicInfoForm.css';

const BasicInfoForm = ({ initialData }) => {
  const [formData, setFormData] = useState({
    name: initialData?.name || '',
    email: initialData?.email || '',
    phone: initialData?.phone || ''
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Actualizando datos:", formData);
    // Aquí llamarías a una función de actualización en el futuro
  };

  return (
    <form className="basic-info-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label>Nombre Completo</label>
        <input 
          type="text" 
          name="name" 
          value={formData.name} 
          onChange={handleChange} 
        />
      </div>
      <div className="form-group">
        <label>Correo Electrónico</label>
        <input 
          type="email" 
          name="email" 
          value={formData.email} 
          readOnly // Generalmente el email no se cambia así de fácil
        />
      </div>
      <button type="submit" className="btn-save">Guardar Cambios</button>
    </form>
  );
};

export default BasicInfoForm;