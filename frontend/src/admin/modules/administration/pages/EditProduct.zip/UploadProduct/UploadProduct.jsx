import React, { useState, useRef, useCallback } from "react";
import InventaryStock from "../Inventary/InventaryStock";
import "./UploadProduct.css";

// ─── Constantes ───────────────────────────────────────────────────────────────
const TALLAS_DISPONIBLES = ["S", "M", "L", "XL", "XXL"];
const CATEGORIAS = ["Pantalones", "Hoodies", "Camisetas", "Accesorios"];
const MAX_IMAGENES = 4;

// ─── Estado inicial del producto ──────────────────────────────────────────────
const estadoInicial = {
  nombre: "",
  descripcion: "",
  precioVenta: "",
  categoria: CATEGORIAS[0],
  tallas: [],
  imagenes: [],
  stock: {}, // stock por talla
};

// ─── Utilidades ───────────────────────────────────────────────────────────────
const crearEntradaImagen = (file) => ({
  file,
  url: URL.createObjectURL(file),
});

const revocarURLs = (imagenes) =>
  imagenes.forEach(({ url }) => URL.revokeObjectURL(url));

// ─── Componente SlotImagen ─────────────────────────────────────────────────────
/**
 * Un slot individual de imagen (grande o miniatura).
 * Acepta click para abrir selector de archivo y drag & drop.
 */
const SlotImagen = ({
  imagen,
  indice,
  esPrincipal,
  onAgregar,
  onEliminar,
  dragging,
  onDragOver,
  onDragLeave,
  onDrop,
}) => {
  const inputRef = useRef(null);

  const handleClick = () => {
    if (!imagen) inputRef.current?.click();
  };

  const handleFileChange = (e) => {
    const file = e.target.files?.[0];
    if (file) onAgregar(indice, file);
    e.target.value = "";
  };

  return (
    <div
      className={[
        esPrincipal ? "mainPreview" : "thumb",
        dragging ? "draggingOver" : "",
        indice === 0 && !esPrincipal ? "thumbActive" : "",
      ]
        .filter(Boolean)
        .join(" ")}
      onClick={handleClick}
      onDragOver={onDragOver}
      onDragLeave={onDragLeave}
      onDrop={(e) => onDrop(e, indice)}
      role="button"
      aria-label={
        imagen ? `Imagen ${indice + 1} cargada` : `Añadir imagen ${indice + 1}`
      }
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && handleClick()}
    >
      {/* Input oculto */}
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hiddenInput"
        onChange={handleFileChange}
        aria-hidden="true"
        tabIndex={-1}
      />

      {/* Contenido del slot */}
      {imagen ? (
        <>
          <img
            src={imagen.url}
            alt={`Vista ${indice + 1}`}
            className={esPrincipal ? "mainImage" : "thumbImage"}
          />
          {esPrincipal && (
            <>
              <div className="primaryTag">Primera vista</div>
              <div className="imageOverlayText">Vista</div>
              <div className="floatingActions">
                <button
                  className="roundBtn"
                  aria-label="Zoom"
                  onClick={(e) => e.stopPropagation()}
                >
                  🔍
                </button>
                <button
                  className="roundBtn"
                  aria-label="Eliminar imagen"
                  onClick={(e) => {
                    e.stopPropagation();
                    onEliminar(indice);
                  }}
                >
                  ✕
                </button>
              </div>
            </>
          )}
          {!esPrincipal && (
            <button
              className="thumbRemoveBtn"
              aria-label="Eliminar miniatura"
              onClick={(e) => {
                e.stopPropagation();
                onEliminar(indice);
              }}
            >
              ✕
            </button>
          )}
        </>
      ) : (
        <div className="slotVacio">
          <span className="slotIcon">{esPrincipal ? "🖼️" : "📷"}</span>
          <small>{esPrincipal ? "Arrastra o haz click" : "Añadir vista"}</small>
        </div>
      )}
    </div>
  );
};

// ─── Componente Principal ──────────────────────────────────────────────────────
const UploadProduct = () => {
  const [producto, setProducto] = useState(estadoInicial);
  // Estado separado para stock por talla
  const [stock, setStock] = useState({});
  const [draggingIndice, setDraggingIndice] = useState(null);

  // ── Handlers de campos de texto ──
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProducto((prev) => ({ ...prev, [name]: value }));
  };

  // ── Toggle de tallas ──
  const toggleTalla = (talla) => {
    setProducto((prev) => {
      const nuevasTallas = prev.tallas.includes(talla)
        ? prev.tallas.filter((t) => t !== talla)
        : [...prev.tallas, talla];
      // Sincronizar stock: eliminar tallas deseleccionadas
      setStock((prevStock) => {
        const nuevoStock = { ...prevStock };
        Object.keys(nuevoStock).forEach((key) => {
          if (!nuevasTallas.includes(key)) delete nuevoStock[key];
        });
        // Añadir tallas nuevas con valor 0
        nuevasTallas.forEach((t) => {
          if (!(t in nuevoStock)) nuevoStock[t] = 0;
        });
        return nuevoStock;
      });
      return { ...prev, tallas: nuevasTallas };
    });
  };
  // ── Handler para cambios de stock ──
  const handleStockChange = useCallback((talla, cantidad) => {
    setStock((prev) => ({ ...prev, [talla]: cantidad }));
  }, []);

  // ── Agregar imagen en un índice específico ──
  const agregarImagen = (indice, file) => {
    setProducto((prev) => {
      const nuevas = [...prev.imagenes];

      // Revocar URL anterior si existe para evitar memory leaks
      if (nuevas[indice]?.url) URL.revokeObjectURL(nuevas[indice].url);

      nuevas[indice] = crearEntradaImagen(file);
      return { ...prev, imagenes: nuevas };
    });
  };

  // ── Eliminar imagen en un índice específico ──
  const eliminarImagen = (indice) => {
    setProducto((prev) => {
      const nuevas = [...prev.imagenes];
      if (nuevas[indice]?.url) URL.revokeObjectURL(nuevas[indice].url);

      // Compactar el array: mover imágenes posteriores hacia adelante
      nuevas.splice(indice, 1);
      return { ...prev, imagenes: nuevas };
    });
  };

  // ── Drag & Drop ──
  const handleDragOver = (e, indice) => {
    e.preventDefault();
    setDraggingIndice(indice);
  };

  const handleDragLeave = () => setDraggingIndice(null);

  const handleDrop = (e, indice) => {
    e.preventDefault();
    setDraggingIndice(null);
    const file = e.dataTransfer.files?.[0];
    if (file && file.type.startsWith("image/")) {
      agregarImagen(indice, file);
    }
  };

  // ── Submit ──
  const handleSubmit = () => {
    const payload = {
      nombre: producto.nombre,
      descripcion: producto.descripcion,
      precioVenta: Number(producto.precioVenta),
      categoria: producto.categoria,
      tallas: producto.tallas,
      imagenes: producto.imagenes.map((img) => img.file),
      stock: { ...stock },
    };
    console.log("Payload producto:", payload);
    // Aquí iría tu llamada a la API: submitProducto(payload)
  };

  const handleEliminar = () => {
    revocarURLs(producto.imagenes);
    setProducto(estadoInicial);
    setStock({});
  };

  // ── Renderizado ──
  return (
    <div className="adminContainer">
      <main className="mainContent">
        {/* Título + acciones */}
        <div className="pageTitleRow">
          <h2 className="pageTitle">SUBIR PRODUCTO</h2>
          <div className="topButtons">
            <button className="btnDiscard" onClick={handleEliminar}>
              ELIMINAR
            </button>
            <button className="btnUpload" onClick={handleSubmit}>
              EDITAR PRODUCTO ⇡
            </button>
          </div>
        </div>

        <section className="gridContainer">
          {/* ── Columna formulario ── */}
          <div className="formColumn">
            <div className="card">
              <h3 className="cardTitle">
                <span className="iconBlue">✎</span> Editar
              </h3>

              <div className="inputGroup">
                <label>Nombre producto</label>
                <input
                  type="text"
                  name="nombre"
                  value={producto.nombre}
                  onChange={handleChange}
                  placeholder="e.g. NEON_VAPOR HOODIE"
                />
              </div>

              <div className="inputGroup">
                <label>Descripción</label>
                <textarea
                  name="descripcion"
                  value={producto.descripcion}
                  onChange={handleChange}
                  placeholder="TECHNICAL SPECIFICATIONS AND DESIGN PHILOSOPHY..."
                />
              </div>

              <div className="row">
                <div className="inputGroup">
                  <label>Precio (COL)</label>
                  <div className="priceInput">
                    <span>$</span>
                    <input
                      type="number"
                      name="precioVenta"
                      value={producto.precioVenta}
                      onChange={handleChange}
                      placeholder="0"
                    />
                  </div>
                </div>
                <div className="inputGroup">
                  <label>Categoría</label>
                  <select
                    name="categoria"
                    value={producto.categoria}
                    onChange={handleChange}
                  >
                    {CATEGORIAS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="sizeSection">
                <label>Tallas</label>
                <div className="sizeGrid">
                  {TALLAS_DISPONIBLES.map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => toggleTalla(t)}
                      className={
                        producto.tallas.includes(t)
                          ? "sizeBtnActive"
                          : "sizeBtnU"
                      }
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="card">
              <h3 className="cardTitle">
                <span className="iconBlue">📋</span> Inventario
              </h3>
              <InventaryStock
                tallas={producto.tallas}
                stock={stock}
                onStockChange={handleStockChange}
              />
            </div>
          </div>

          {/* ── Columna vista previa ── */}
          <div className="previewColumn">
            {/* Slot principal (índice 0) */}
            <SlotImagen
              indice={0}
              esPrincipal
              imagen={producto.imagenes[0] ?? null}
              onAgregar={agregarImagen}
              onEliminar={eliminarImagen}
              dragging={draggingIndice === 0}
              onDragOver={(e) => handleDragOver(e, 0)}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
            />

            {/* Miniaturas (índices 1, 2, 3) */}
            <div className="thumbnailRow">
              {[1, 2, 3].map((idx) => (
                <SlotImagen
                  key={idx}
                  indice={idx}
                  esPrincipal={false}
                  imagen={producto.imagenes[idx] ?? null}
                  onAgregar={agregarImagen}
                  onEliminar={eliminarImagen}
                  dragging={draggingIndice === idx}
                  onDragOver={(e) => handleDragOver(e, idx)}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                />
              ))}

              {/* Contador de imágenes */}
              <div className="thumbCount">
                <span>{producto.imagenes.length}</span>
                <small>/ {MAX_IMAGENES}</small>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
};

export default UploadProduct;
