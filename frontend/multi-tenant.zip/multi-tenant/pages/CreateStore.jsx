import "../components/styles/Store.css";
import "../components/styles/StepPages.css";
import { useNavigate } from "react-router-dom";
import { useStore } from "../pages/StoreContext";
import { useState } from "react";
import { createUser } from "./services/userService";
import VexioTermsPage from "../components/VexioTermsPage";
import StepProgress from "../components/StepProgress";

export default function CreateStore() {
  const nav = useNavigate();
  const { state, completeStep, saveProgress } = useStore();

  // Pre-carga datos guardados si el usuario regresa
  const [form, setForm] = useState({
    name: state.basic?.name ?? state.store?.name ?? "",
    subdomain: state.store?.subdomain ?? "",
    accepted: state.store?.accepted ?? false,
  });

  const [approved, setApproved] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleBack = () => {
    saveProgress("store", form);
    nav("/crear-tienda/pagos");
  };

  const handleSubmit = async () => {
    setError("");
    if (!form.name || !form.subdomain) {
      setError("Completa todos los campos obligatorios.");
      return;
    }
    if (!form.accepted) {
      setError("Debes aceptar los términos y condiciones.");
      return;
    }
    setLoading(true);
    try {
      // Llama a la API para crear el usuario/tienda
      const userPayload = {
        name: form.name,
        subdomain: form.subdomain,
        // Puedes agregar más campos si la API lo requiere
      };
      await createUser(userPayload);
      setApproved(true);
      completeStep("store", {
        name: form.name,
        subdomain: form.subdomain,
        accepted: form.accepted,
      });
      completeStep(2, {
        name: form.name,
        subdomain: form.subdomain,
        accepted: form.accepted,
      });
      setTimeout(() => {
        nav("/layout");
      }, 1200);
    } catch (err) {
      setError(err.message || "Error al crear el usuario. Intenta nuevamente.");
      setApproved(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="step-page">
      <StepProgress />

      <div className="step-card" style={{ maxWidth: 680 }}>
        <div className="step-header">
          <button className="btn-back" onClick={handleBack}>
            ←
          </button>
          <div>
            <h1 className="step-title">Términos y crear tienda</h1>
            <p className="step-subtitle">
              {state.plan && (
                <>
                  Plan: <strong>{state.plan.name}</strong>
                </>
              )}
            </p>
          </div>
        </div>

        <div className="step-body">
          <div className="field-block">
            <label>Nombre de la tienda *</label>
            <input
              placeholder="Nombre tienda"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </div>

          <div className="field-block">
            <label>Subdominio *</label>
            <input
              placeholder="mi-tienda"
              value={form.subdomain}
              onChange={(e) => setForm({ ...form, subdomain: e.target.value })}
            />
          </div>

          <div className="field-block">
            <label>Términos y condiciones</label>
            <div className="terms-scroll-box">
              <VexioTermsPage />
            </div>
          </div>

          <section className="terms-acceptance">
            <label
              className="checkbox-container"
              style={{
                display: "flex",
                gap: 10,
                alignItems: "flex-start",
                cursor: "pointer",
              }}
            >
              <input
                type="checkbox"
                checked={form.accepted}
                onChange={(e) =>
                  setForm({ ...form, accepted: e.target.checked })
                }
                style={{ width: "auto", margin: 0, marginTop: 2 }}
              />
              <span style={{ fontSize: 13, color: "#aaa", lineHeight: 1.5 }}>
                He leído y acepto los términos y condiciones, políticas de
                privacidad y normas comerciales establecidas por Vexio.
              </span>
            </label>
          </section>

          {error && (
            <div className="alert error" style={{ marginBottom: 12 }}>
              {error}
            </div>
          )}
          {approved && (
            <div className="alert success">✔ Tienda creada correctamente</div>
          )}
        </div>

        <div className="step-actions">
          <button
            className="btn-secondary"
            onClick={handleBack}
            disabled={loading}
          >
            Atrás
          </button>
          <button
            className="btn-primary"
            onClick={handleSubmit}
            disabled={approved || loading}
          >
            {loading
              ? "Creando..."
              : approved
                ? "Redirigiendo..."
                : "Crear tienda →"}
          </button>
        </div>
      </div>
    </div>
  );
}
