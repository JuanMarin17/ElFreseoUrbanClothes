/**
 * StoreContext.jsx
 * Persiste todo el flujo de creación de tienda en localStorage.
 */

import { createContext, useContext, useState, useCallback } from "react";

const STORAGE_KEY = "mt_store_flow";

const DEFAULT_STATE = {
  completedStep: 0,
  plan:       null, // paso 1  – { id, name, price, features }
  basic:      null, // paso 2a – { name, description, logoPreview }
  legal:      null, // paso 2b – { legalName, idNumber, documentName }
  payment:    null, // paso 2c – { paymentMethod, shipping }
  store:      null, // paso 2d – { name, subdomain, accepted }  (términos)
  layout:     null, // paso 3  – { id, title, description }
  styles:     null, // paso 4  – { colorBoton, cardBg, fontTitle, ... }
  components: null, // paso 5  – { header, banner, footer }
  widgets:    null, // paso 6  – { sidebar, searchbar }
};

/* ── Helpers localStorage ─────────────────────────── */
function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? { ...DEFAULT_STATE, ...JSON.parse(raw) } : DEFAULT_STATE;
  } catch {
    return DEFAULT_STATE;
  }
}

function persist(state) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn("Error guardando en localStorage:", e);
  }
}

/**
 * Resuelve el nombre del campo en el estado a partir de un número o string.
 * Números (legado): 1→plan, 2→store, 3→layout, 4→styles, 5→components
 * Strings (nuevo):  "basic", "legal", "payment", "store", "layout", "styles", "components"
 */
const NUMERIC_MAP = {
  1: "plan",
  2: "store",
  3: "layout",
  4: "styles",
  5: "components",
  6: "widgets",
};

function resolveField(key) {
  if (typeof key === "number") return NUMERIC_MAP[key] ?? null;
  return key; // ya es string
}

/**
 * Orden de pasos para calcular completedStep cuando se usa string.
 * Cuanto mayor el índice, más avanzado el flujo.
 */
const STEP_ORDER = ["plan", "basic", "legal", "payment", "store", "layout", "styles", "components", "widgets"];

function stepIndex(key) {
  const field = resolveField(key);
  const idx = STEP_ORDER.indexOf(field);
  return idx >= 0 ? idx : -1;
}

/* ── Context ──────────────────────────────────────── */
const StoreContext = createContext();

export const StoreProvider = ({ children }) => {
  const [state, setState] = useState(load);

  /**
   * Guarda los datos de un paso y lo marca como completado.
   * Acepta número (legado) o string (nuevo).
   *
   * completeStep(1, { id: "pro", name: "PRO" })
   * completeStep("basic", { name: "Mi Tienda" })
   */
  const completeStep = useCallback((key, data = {}) => {
    const field = resolveField(key);
    if (!field) return;
    const idx = stepIndex(key);
    setState((prev) => {
      const next = {
        ...prev,
        [field]: data,
        completedStep: Math.max(prev.completedStep, idx >= 0 ? idx : (typeof key === "number" ? key : 0)),
      };
      persist(next);
      return next;
    });
  }, []);

  /**
   * Guarda progreso parcial SIN avanzar el paso.
   * Acepta número (legado) o string (nuevo).
   */
  const saveProgress = useCallback((key, data = {}) => {
    const field = resolveField(key);
    if (!field) return;
    setState((prev) => {
      const next = { ...prev, [field]: data };
      persist(next);
      return next;
    });
  }, []);

  /** Limpia todo */
  const resetAll = useCallback(() => {
    localStorage.removeItem(STORAGE_KEY);
    setState(DEFAULT_STATE);
  }, []);

  /** Reinicia un paso específico y todos los siguientes (acepta número o string) */
  const resetStep = useCallback((key) => {
    const idx = stepIndex(key);
    setState((prev) => {
      const next = { ...prev, completedStep: Math.max(0, idx - 1) };
      // Limpia todos los campos desde ese paso en adelante
      STEP_ORDER.slice(idx).forEach((f) => { next[f] = null; });
      persist(next);
      return next;
    });
  }, []);

  /** Compatibilidad con el update() original */
  const update = useCallback((field, value) => {
    setState((prev) => {
      const next = { ...prev, [field]: value };
      persist(next);
      return next;
    });
  }, []);

  return (
    <StoreContext.Provider
      value={{
        state,
        store: state,
        update,
        completeStep,
        saveProgress,
        resetAll,
        resetStep,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
};

export const useStore = () => useContext(StoreContext);
