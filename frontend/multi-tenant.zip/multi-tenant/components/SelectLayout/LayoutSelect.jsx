import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useStore } from "../../pages/StoreContext";
import "../../components/styles/LayoutSelect.css";
import SelectLayout from "./SelectLayout.jsx";
import { Layout1 } from "./Layout1.jsx";
import StepProgress from "../StepProgress";

import layout1 from "../../../src/assets/Layout/layout1.png";
import layout2 from "../../../src/assets/Layout/layout2.png";
import layout3 from "../../../src/assets/Layout/layout3.png";

const layouts = [
  {
    id: "minimalista",
    title: "MINIMALISTA",
    description: "Diseño limpio y elegante, enfocado en el producto.",
    img: layout1,
  },
  {
    id: "urbano",
    title: "URBANO / STREETWEAR",
    description: "Diseño impactante y moderno, ideal para marcas urbanas.",
    img: layout2,
  },
  {
    id: "clasico",
    title: "CLÁSICO ECOMMERCE",
    description: "Diseño tradicional, enfocado en conversión y catálogo.",
    img: layout3,
  },
];

const LayoutSelect = () => {
  const { state, completeStep } = useStore();
  const navigate = useNavigate();

  // Pre-carga el layout guardado si el usuario regresa
  const [selected, setSelected] = useState(state.layout?.id ?? "minimalista");
  const [showPreview, setShowPreview] = useState(false);

  // Cuando elige un layout: guarda selección y muestra preview
  const handleSelect = (id) => {
    setSelected(id);
    setShowPreview(true);
  };

  // Flecha atrás — guarda progreso y vuelve al paso 2
  const handleBack = () => {
    const layoutData = layouts.find((l) => l.id === selected);
    completeStep(3, layoutData);
    navigate("/crear-tienda");
  };

  // Continuar — guarda layout y avanza al paso 4
  const handleContinue = () => {
    const layoutData = layouts.find((l) => l.id === selected);
    completeStep(3, layoutData);
    navigate("/customer");
  };

  return (
    <div className="layout-select-page">
      <StepProgress />

      <main className="layout-main-content">

        {/* — VISTA: Selección de layout — */}
        {!showPreview && (
          <section className="selection-area">

            <div className="selection-header">
              {/* Flecha atrás */}
              <button
                onClick={handleBack}
                style={{
                  background: "transparent",
                  border: "none",
                  color: "inherit",
                  fontSize: "22px",
                  cursor: "pointer",
                  padding: "0",
                }}
                title="Volver al paso anterior"
              >
                ←
              </button>
              <div>
                <h1>ELEGIR LAYOUT</h1>
                <p>Selecciona la estructura base de tu tienda</p>
              </div>
            </div>

            <div className="options-grid">
              {layouts.map((layout) => (
                <SelectLayout
                  key={layout.id}
                  layout={layout}
                  isSelected={selected === layout.id}
                  onSelect={handleSelect} 
                />
              ))}
            </div>

            <div className="actions">
              <button className="btn-continue" onClick={handleContinue}>
                CONTINUAR
              </button>
            </div>
          </section>
        )}

        {/* — VISTA: Preview del layout elegido — */}
        {showPreview && (
          <section className="preview-area">

            <div className="preview-topbar">
              {/* Volver a la selección */}
              <button
                className="btn-back-preview"
                onClick={() => setShowPreview(false)}
              >
                ← Cambiar layout
              </button>

              <span className="preview-label">
                Vista previa:{" "}
                <strong>
                  {layouts.find((l) => l.id === selected)?.title}
                </strong>
              </span>

              <button className="btn-continue-small" onClick={handleContinue}>
                CONFIRMAR Y CONTINUAR →
              </button>
            </div>

            {/* Layout1 recibe el id del layout elegido y cambia su estilo */}
            <div className="layout-preview-wrapper">
              <Layout1 layoutType={selected} />
            </div>

          </section>
        )}

      </main>
    </div>
  );
};

export default LayoutSelect;