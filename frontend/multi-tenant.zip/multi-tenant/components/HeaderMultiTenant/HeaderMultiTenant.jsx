import React from "react";
import "../HeaderMultiTenant/HeaderMultiTenant.css"
import { ArrowLeft } from "lucide-react";

const HeaderMultiTenant = ({ title }) => {
  return (
    <div className="header">
      <div className="headerLeft">
        <button className="backBtn">
          <ArrowLeft size={20} />
        </button>
        <h1>{title}</h1>
      </div>

      <div className="userInfo">
        <span>Operator</span>
        <strong>A. FRESEO</strong>
      </div>
    </div>
  );
};

export default HeaderMultiTenant;
